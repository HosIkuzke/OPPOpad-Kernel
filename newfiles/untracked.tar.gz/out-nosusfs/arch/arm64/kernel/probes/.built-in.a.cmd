cmd_arch/arm64/kernel/probes/built-in.a :=  rm -f arch/arm64/kernel/probes/built-in.a; llvm-ar rcSTPD arch/arm64/kernel/probes/built-in.a 
