cmd_arch/arm64/kernel/vdso32/built-in.a :=  rm -f arch/arm64/kernel/vdso32/built-in.a; llvm-ar rcSTPD arch/arm64/kernel/vdso32/built-in.a arch/arm64/kernel/vdso32/vdso.o
