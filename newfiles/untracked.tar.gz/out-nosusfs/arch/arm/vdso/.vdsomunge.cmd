cmd_arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge := gcc -Wp,-MD,arch/arm64/kernel/vdso32/../../../arm/vdso/.vdsomunge.d -Iarch/arm64/kernel/vdso32 -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89   -o arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge ../arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge.c   

source_arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge := ../arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge.c

deps_arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge := \
  /usr/include/stdc-predef.h \
  /usr/include/elf.h \
  /usr/include/stdint.h \
  /usr/include/bits/alltypes.h \
  /usr/include/bits/stdint.h \
  /usr/include/errno.h \
  /usr/include/features.h \
  /usr/include/bits/errno.h \
  /usr/include/fcntl.h \
  /usr/include/bits/fcntl.h \
  /usr/include/stdarg.h \
  /usr/include/stdbool.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/sys/mman.h \
  /usr/include/bits/mman.h \
  /usr/include/sys/stat.h \
  /usr/include/bits/stat.h \
  /usr/include/sys/types.h \
  /usr/include/endian.h \
  /usr/include/fortify/sys/select.h \
  /usr/include/sys/select.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \

arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge: $(deps_arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge)

$(deps_arch/arm64/kernel/vdso32/../../../arm/vdso/vdsomunge):
