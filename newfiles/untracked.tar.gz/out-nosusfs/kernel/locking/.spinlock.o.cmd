cmd_kernel/locking/spinlock.o := clang -Wp,-MD,kernel/locking/.spinlock.o.d -nostdinc -isystem /usr/lib/llvm22/lib/clang/22/include -I../arch/arm64/include -I./arch/arm64/include/generated  -I../include -I./include -I../arch/arm64/include/uapi -I./arch/arm64/include/generated/uapi -I../include/uapi -I./include/generated/uapi -include ../include/linux/kconfig.h -include ../include/linux/compiler_types.h  -I../kernel/locking -Ikernel/locking -D__KERNEL__ -DVENDOR_EDIT -DOPLUS_FEATURE_POWER_EFFICIENCY -DOPLUS_FEATURE_WIFI_MTUDETECT -DOPLUS_FEATURE_FG_IO_OPT -DOPLUS_FEATURE_SPECIALOPT -DOPLUS_FEATURE_PERFORMANCE -DOPLUS_FEATURE_STORAGE_TOOL -DOPLUS_FEATURE_UFS_DRIVER -DOPLUS_FEATURE_UFS_SHOW_LATENCY -DOPLUS_FEATURE_UFSPLUS -DOPLUS_FEATURE_PADL_STATISTICS -DOPLUS_FEATURE_EMMC_SDCARD_OPTIMIZE -DOPLUS_FEATURE_EMMC_DRIVER -DOPLUS_FEATURE_HEALTHINFO -DOPLUS_FEATURE_TASK_CPUSTATS -DOPLUS_FEATURE_HANS_FREEZE -DOPLUS_FEATURE_SCHED_ASSIST -DOPLUS_FEATURE_IOMONITOR -DOPLUS_FEATURE_TP_BSPFWUPDATE -DOPLUS_FEATURE_QCOM_PMICWD -DOPLUS_FEATURE_CHG_BASIC -DOPLUS_FEATURE_NWPOWER -DOPLUS_FEATURE_WIFI_BDF -DOPLUS_FEATURE_CONNFCSOFT -DOPLUS_FEATURE_AGINGTEST -DOPLUS_FEATURE_SENSOR_SMEM -DOPLUS_FEATURE_SSR -DOPLUS_FEATURE_TP_BASIC -DOPLUS_FEATURE_EDTASK_IMPROVE -DOPLUS_FEATURE_WIFI_SLA -DOPLUS_FEATURE_WIFI_ROUTERBOOST -DOPLUS_FEATURE_IPV6_OPTIMIZE -DOPLUS_FEATURE_DATA_EVAL -DOPLUS_FEATURE_DHCP -DOPLUS_FEATURE_KMSG_WB -DOPLUS_FEATURE_SHUTDOWN_SPEED -DOPLUS_FEATURE_OLC -DOPLUS_FEATURE_DUMPDEVICE -DOPLUS_FEATURE_SAUPWK -DOPLUS_FEATURE_MEMORY_ISOLATE -DOPLUS_FEATURE_MULTI_KSWAPD -DOPLUS_FEATURE_WIFI_MTUDETECT -DOPLUS_FEATURE_XTOWNER_INPUT -DOPLUS_FEATURE_PXLW_IRIS5 -DOPLUS_FEATURE_MULTI_FREEAREA -DOPLUS_FEATURE_VIRTUAL_RESERVE_MEMORY -DOPLUS_FEATURE_GPU_MINIDUMP -DOPLUS_FEATURE_PROCESS_RECLAIM -DOPLUS_FEATURE_ZRAM_OPT -DOPLUS_FEATURE_AUDIO_FTM -DOPLUS_FEATURE_SPEAKER_MUTE -DOPLUS_FEATURE_MI2S_SLAVE -DOPLUS_FEATURE_KTV -DOPLUS_FEATURE_QCOM_WATCHDOG -DOPLUS_FEATURE_MEMLEAK_DETECT -DOPLUS_FEATURE_EXFAT_SUPPORT -DOPLUS_FEATURE_SDCARDFS_SUPPORT -DOPLUS_FEATURE_CAMERA_OIS -DOPLUS_BUG_COMPATIBILITY -DOPLUS_BUG_STABILITY -DOPLUS_BUG_DEBUG -DOPLUS_ARCH_INJECT -DOPLUS_ARCH_EXTENDS -DOPLUS_FEATURE_AUDIODETECT -DVENDOR_EDIT -DOPLUS_FEATURE_DC -DOPLUS_FEATURE_POWERINFO_STANDBY -DOPLUS_FEATURE_POWERINFO_RPMH -DOPLUS_FEATURE_CAMERA_COMMON -DOPLUS_FEATURE_ADSP_RECOVERY -DOPLUS_FEATURE_SMARTPA_PM -DOPLUS_FEATURE_IMPEDANCE_MATCH -DOPLUS_FEATURE_MODEM_MINIDUMP -DOPLUS_FEATURE_THEIA -DOPLUS_FEATURE_POWER_CPUFREQ -DOPLUS_FEATURE_MIDAS -DOPLUS_FEATURE_WIFI_OPLUSWFD -DOPLUS_FEATURE_WIFI_DUALSTA_AP_BLACKLIST -DOPLUS_FEATURE_WIFI_DCS_SWITCH -DOPLUS_FEATURE_SOFTAP_DCS_SWITCH -DOPLUS_FEATURE_IM -DOPLUS_FEATURE_TPD -DOPLUS_FEATURE_APP_MONITOR -DOPLUS_FEATURE_RT_INFO -DOPLUS_FEATURE_MIC_VA_MIC_CLK_SWITCH -DOPLUS_FEATURE_SIGKILL_DIAGNOSIS -DOPLUS_FEATURE_SENSOR -DOPLUS_FEATURE_ADFR -mlittle-endian -DKASAN_SHADOW_SCALE_SHIFT=3 -Qunused-arguments -Wall -Wundef -Wstrict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -Werror-implicit-function-declaration -Werror=return-type -Wno-format-security -Wno-default-const-init-var-unsafe -Wno-default-const-init-field-unsafe -std=gnu89 -DVENDOR_EDIT -DOPLUS_FEATURE_POWER_EFFICIENCY -DOPLUS_FEATURE_WIFI_MTUDETECT -DOPLUS_FEATURE_FG_IO_OPT -DOPLUS_FEATURE_SPECIALOPT -DOPLUS_FEATURE_PERFORMANCE -DOPLUS_FEATURE_STORAGE_TOOL -DOPLUS_FEATURE_UFS_DRIVER -DOPLUS_FEATURE_UFS_SHOW_LATENCY -DOPLUS_FEATURE_UFSPLUS -DOPLUS_FEATURE_PADL_STATISTICS -DOPLUS_FEATURE_EMMC_SDCARD_OPTIMIZE -DOPLUS_FEATURE_EMMC_DRIVER -DOPLUS_FEATURE_HEALTHINFO -DOPLUS_FEATURE_TASK_CPUSTATS -DOPLUS_FEATURE_HANS_FREEZE -DOPLUS_FEATURE_SCHED_ASSIST -DOPLUS_FEATURE_IOMONITOR -DOPLUS_FEATURE_TP_BSPFWUPDATE -DOPLUS_FEATURE_QCOM_PMICWD -DOPLUS_FEATURE_CHG_BASIC -DOPLUS_FEATURE_NWPOWER -DOPLUS_FEATURE_WIFI_BDF -DOPLUS_FEATURE_CONNFCSOFT -DOPLUS_FEATURE_AGINGTEST -DOPLUS_FEATURE_SENSOR_SMEM -DOPLUS_FEATURE_SSR -DOPLUS_FEATURE_TP_BASIC -DOPLUS_FEATURE_EDTASK_IMPROVE -DOPLUS_FEATURE_WIFI_SLA -DOPLUS_FEATURE_WIFI_ROUTERBOOST -DOPLUS_FEATURE_IPV6_OPTIMIZE -DOPLUS_FEATURE_DATA_EVAL -DOPLUS_FEATURE_DHCP -DOPLUS_FEATURE_KMSG_WB -DOPLUS_FEATURE_SHUTDOWN_SPEED -DOPLUS_FEATURE_OLC -DOPLUS_FEATURE_DUMPDEVICE -DOPLUS_FEATURE_SAUPWK -DOPLUS_FEATURE_MEMORY_ISOLATE -DOPLUS_FEATURE_MULTI_KSWAPD -DOPLUS_FEATURE_WIFI_MTUDETECT -DOPLUS_FEATURE_XTOWNER_INPUT -DOPLUS_FEATURE_PXLW_IRIS5 -DOPLUS_FEATURE_MULTI_FREEAREA -DOPLUS_FEATURE_VIRTUAL_RESERVE_MEMORY -DOPLUS_FEATURE_GPU_MINIDUMP -DOPLUS_FEATURE_PROCESS_RECLAIM -DOPLUS_FEATURE_ZRAM_OPT -DOPLUS_FEATURE_AUDIO_FTM -DOPLUS_FEATURE_SPEAKER_MUTE -DOPLUS_FEATURE_MI2S_SLAVE -DOPLUS_FEATURE_KTV -DOPLUS_FEATURE_QCOM_WATCHDOG -DOPLUS_FEATURE_MEMLEAK_DETECT -DOPLUS_FEATURE_EXFAT_SUPPORT -DOPLUS_FEATURE_SDCARDFS_SUPPORT -DOPLUS_FEATURE_CAMERA_OIS -DOPLUS_BUG_COMPATIBILITY -DOPLUS_BUG_STABILITY -DOPLUS_BUG_DEBUG -DOPLUS_ARCH_INJECT -DOPLUS_ARCH_EXTENDS -DOPLUS_FEATURE_AUDIODETECT -DVENDOR_EDIT -DOPLUS_FEATURE_DC -DOPLUS_FEATURE_POWERINFO_STANDBY -DOPLUS_FEATURE_POWERINFO_RPMH -DOPLUS_FEATURE_CAMERA_COMMON -DOPLUS_FEATURE_ADSP_RECOVERY -DOPLUS_FEATURE_SMARTPA_PM -DOPLUS_FEATURE_IMPEDANCE_MATCH -DOPLUS_FEATURE_MODEM_MINIDUMP -DOPLUS_FEATURE_THEIA -DOPLUS_FEATURE_POWER_CPUFREQ -DOPLUS_FEATURE_MIDAS -DOPLUS_FEATURE_WIFI_OPLUSWFD -DOPLUS_FEATURE_WIFI_DUALSTA_AP_BLACKLIST -DOPLUS_FEATURE_WIFI_DCS_SWITCH -DOPLUS_FEATURE_SOFTAP_DCS_SWITCH -DOPLUS_FEATURE_IM -DOPLUS_FEATURE_TPD -DOPLUS_FEATURE_APP_MONITOR -DOPLUS_FEATURE_RT_INFO -DOPLUS_FEATURE_MIC_VA_MIC_CLK_SWITCH -DOPLUS_FEATURE_SIGKILL_DIAGNOSIS -DOPLUS_FEATURE_SENSOR -DOPLUS_FEATURE_ADFR --target=aarch64-linux-gnu --prefix=aarch64-linux-gnu- --gcc-toolchain=/ -no-integrated-as -Werror=unknown-warning-option -Wno-unsequenced -fno-PIE -mno-implicit-float -DCONFIG_AS_LSE=1 -fno-asynchronous-unwind-tables -Wno-psabi -DKASAN_SHADOW_SCALE_SHIFT=3 -fno-delete-null-pointer-checks -Wno-frame-address -Wno-format-truncation -Wno-format-overflow -Wno-int-in-bool-context -Wno-address-of-packed-member -O2 -Wframe-larger-than=2048 -fstack-protector-strong --target=aarch64-linux-gnu --gcc-toolchain=/usr -meabi gnu -Wno-format-invalid-specifier -Wno-gnu -Wno-duplicate-decl-specifier -Wno-asm-operand-widths -Wno-initializer-overrides -Wno-tautological-constant-out-of-range-compare -Wno-tautological-compare -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -Wvla -Wdeclaration-after-statement -Wno-pointer-sign -Wno-array-bounds -fno-strict-overflow -fno-merge-all-constants -fno-stack-check -Werror=implicit-int -Werror=strict-prototypes -Werror=date-time -Werror=incompatible-pointer-types -Wno-error=strict-prototypes -Wno-error=date-time -fmacro-prefix-map=../= -Wno-initializer-overrides -Wno-unused-value -Wno-format -Wno-sign-compare -Wno-format-zero-length -Wno-uninitialized -Wno-pointer-to-enum-cast -Wno-unaligned-access -Wno-cast-function-type-strict -Wno-pointer-to-int-cast -Wno-void-pointer-to-int-cast -Wno-enum-compare-conditional -Wno-enum-enum-conversion   -DVENDOR_EDIT -DOPLUS_FEATURE_POWER_EFFICIENCY -DOPLUS_FEATURE_WIFI_MTUDETECT -DOPLUS_FEATURE_FG_IO_OPT -DOPLUS_FEATURE_SPECIALOPT -DOPLUS_FEATURE_PERFORMANCE -DOPLUS_FEATURE_STORAGE_TOOL -DOPLUS_FEATURE_UFS_DRIVER -DOPLUS_FEATURE_UFS_SHOW_LATENCY -DOPLUS_FEATURE_UFSPLUS -DOPLUS_FEATURE_PADL_STATISTICS -DOPLUS_FEATURE_EMMC_SDCARD_OPTIMIZE -DOPLUS_FEATURE_EMMC_DRIVER -DOPLUS_FEATURE_HEALTHINFO -DOPLUS_FEATURE_TASK_CPUSTATS -DOPLUS_FEATURE_HANS_FREEZE -DOPLUS_FEATURE_SCHED_ASSIST -DOPLUS_FEATURE_IOMONITOR -DOPLUS_FEATURE_TP_BSPFWUPDATE -DOPLUS_FEATURE_QCOM_PMICWD -DOPLUS_FEATURE_CHG_BASIC -DOPLUS_FEATURE_NWPOWER -DOPLUS_FEATURE_WIFI_BDF -DOPLUS_FEATURE_CONNFCSOFT -DOPLUS_FEATURE_AGINGTEST -DOPLUS_FEATURE_SENSOR_SMEM -DOPLUS_FEATURE_SSR -DOPLUS_FEATURE_TP_BASIC -DOPLUS_FEATURE_EDTASK_IMPROVE -DOPLUS_FEATURE_WIFI_SLA -DOPLUS_FEATURE_WIFI_ROUTERBOOST -DOPLUS_FEATURE_IPV6_OPTIMIZE -DOPLUS_FEATURE_DATA_EVAL -DOPLUS_FEATURE_DHCP -DOPLUS_FEATURE_KMSG_WB -DOPLUS_FEATURE_SHUTDOWN_SPEED -DOPLUS_FEATURE_OLC -DOPLUS_FEATURE_DUMPDEVICE -DOPLUS_FEATURE_SAUPWK -DOPLUS_FEATURE_MEMORY_ISOLATE -DOPLUS_FEATURE_MULTI_KSWAPD -DOPLUS_FEATURE_WIFI_MTUDETECT -DOPLUS_FEATURE_XTOWNER_INPUT -DOPLUS_FEATURE_PXLW_IRIS5 -DOPLUS_FEATURE_MULTI_FREEAREA -DOPLUS_FEATURE_VIRTUAL_RESERVE_MEMORY -DOPLUS_FEATURE_GPU_MINIDUMP -DOPLUS_FEATURE_PROCESS_RECLAIM -DOPLUS_FEATURE_ZRAM_OPT -DOPLUS_FEATURE_AUDIO_FTM -DOPLUS_FEATURE_SPEAKER_MUTE -DOPLUS_FEATURE_MI2S_SLAVE -DOPLUS_FEATURE_KTV -DOPLUS_FEATURE_QCOM_WATCHDOG -DOPLUS_FEATURE_MEMLEAK_DETECT -DOPLUS_FEATURE_EXFAT_SUPPORT -DOPLUS_FEATURE_SDCARDFS_SUPPORT -DOPLUS_FEATURE_CAMERA_OIS -DOPLUS_BUG_COMPATIBILITY -DOPLUS_BUG_STABILITY -DOPLUS_BUG_DEBUG -DOPLUS_ARCH_INJECT -DOPLUS_ARCH_EXTENDS -DOPLUS_FEATURE_AUDIODETECT -DVENDOR_EDIT -DOPLUS_FEATURE_DC -DOPLUS_FEATURE_POWERINFO_STANDBY -DOPLUS_FEATURE_POWERINFO_RPMH -DOPLUS_FEATURE_CAMERA_COMMON -DOPLUS_FEATURE_ADSP_RECOVERY -DOPLUS_FEATURE_SMARTPA_PM -DOPLUS_FEATURE_IMPEDANCE_MATCH -DOPLUS_FEATURE_MODEM_MINIDUMP -DOPLUS_FEATURE_THEIA -DOPLUS_FEATURE_POWER_CPUFREQ -DOPLUS_FEATURE_MIDAS -DOPLUS_FEATURE_WIFI_OPLUSWFD -DOPLUS_FEATURE_WIFI_DUALSTA_AP_BLACKLIST -DOPLUS_FEATURE_WIFI_DCS_SWITCH -DOPLUS_FEATURE_SOFTAP_DCS_SWITCH -DOPLUS_FEATURE_IM -DOPLUS_FEATURE_TPD -DOPLUS_FEATURE_APP_MONITOR -DOPLUS_FEATURE_RT_INFO -DOPLUS_FEATURE_MIC_VA_MIC_CLK_SWITCH -DOPLUS_FEATURE_SIGKILL_DIAGNOSIS -DOPLUS_FEATURE_SENSOR -DOPLUS_FEATURE_ADFR -DKBUILD_BASENAME='"spinlock"' -DKBUILD_MODNAME='"spinlock"' -c -o kernel/locking/spinlock.o ../kernel/locking/spinlock.c

source_kernel/locking/spinlock.o := ../kernel/locking/spinlock.c

deps_kernel/locking/spinlock.o := \
    $(wildcard include/config/preempt.h) \
    $(wildcard include/config/generic/lockbreak.h) \
    $(wildcard include/config/debug/lock/alloc.h) \
    $(wildcard include/config/inline/spin/trylock.h) \
    $(wildcard include/config/inline/spin/trylock/bh.h) \
    $(wildcard include/config/inline/spin/lock.h) \
    $(wildcard include/config/inline/spin/lock/irqsave.h) \
    $(wildcard include/config/inline/spin/lock/irq.h) \
    $(wildcard include/config/inline/spin/lock/bh.h) \
    $(wildcard include/config/uninline/spin/unlock.h) \
    $(wildcard include/config/inline/spin/unlock/irqrestore.h) \
    $(wildcard include/config/inline/spin/unlock/irq.h) \
    $(wildcard include/config/inline/spin/unlock/bh.h) \
    $(wildcard include/config/inline/read/trylock.h) \
    $(wildcard include/config/inline/read/lock.h) \
    $(wildcard include/config/inline/read/lock/irqsave.h) \
    $(wildcard include/config/inline/read/lock/irq.h) \
    $(wildcard include/config/inline/read/lock/bh.h) \
    $(wildcard include/config/inline/read/unlock.h) \
    $(wildcard include/config/inline/read/unlock/irqrestore.h) \
    $(wildcard include/config/inline/read/unlock/irq.h) \
    $(wildcard include/config/inline/read/unlock/bh.h) \
    $(wildcard include/config/inline/write/trylock.h) \
    $(wildcard include/config/inline/write/lock.h) \
    $(wildcard include/config/inline/write/lock/irqsave.h) \
    $(wildcard include/config/inline/write/lock/irq.h) \
    $(wildcard include/config/inline/write/lock/bh.h) \
    $(wildcard include/config/inline/write/unlock.h) \
    $(wildcard include/config/inline/write/unlock/irqrestore.h) \
    $(wildcard include/config/inline/write/unlock/irq.h) \
    $(wildcard include/config/inline/write/unlock/bh.h) \
  ../include/linux/kconfig.h \
    $(wildcard include/config/cc/version/text.h) \
    $(wildcard include/config/cpu/big/endian.h) \
    $(wildcard include/config/booger.h) \
    $(wildcard include/config/foo.h) \
  ../include/linux/compiler_types.h \
    $(wildcard include/config/have/arch/compiler/h.h) \
    $(wildcard include/config/enable/must/check.h) \
    $(wildcard include/config/arch/supports/optimized/inlining.h) \
    $(wildcard include/config/optimize/inlining.h) \
  ../include/linux/compiler_attributes.h \
  ../include/linux/compiler-clang.h \
    $(wildcard include/config/cfi/clang.h) \
    $(wildcard include/config/lto/clang.h) \
    $(wildcard include/config/ftrace/mcount/record.h) \
  ../include/linux/linkage.h \
  ../include/linux/stringify.h \
  ../include/linux/export.h \
    $(wildcard include/config/modules.h) \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/module/rel/crcs.h) \
    $(wildcard include/config/have/arch/prel32/relocations.h) \
    $(wildcard include/config/trim/unused/ksyms.h) \
    $(wildcard include/config/unused/symbols.h) \
  ../arch/arm64/include/asm/linkage.h \
  ../include/linux/preempt.h \
    $(wildcard include/config/preempt/count.h) \
    $(wildcard include/config/debug/preempt.h) \
    $(wildcard include/config/trace/preempt/toggle.h) \
    $(wildcard include/config/preempt/notifiers.h) \
  ../include/linux/list.h \
    $(wildcard include/config/debug/list.h) \
  ../include/linux/types.h \
    $(wildcard include/config/have/uid16.h) \
    $(wildcard include/config/uid16.h) \
    $(wildcard include/config/lbdaf.h) \
    $(wildcard include/config/arch/dma/addr/t/64bit.h) \
    $(wildcard include/config/phys/addr/t/64bit.h) \
    $(wildcard include/config/64bit.h) \
  ../include/uapi/linux/types.h \
  arch/arm64/include/generated/uapi/asm/types.h \
  ../include/uapi/asm-generic/types.h \
  ../include/asm-generic/int-ll64.h \
  ../include/uapi/asm-generic/int-ll64.h \
  ../arch/arm64/include/uapi/asm/bitsperlong.h \
  ../include/asm-generic/bitsperlong.h \
  ../include/uapi/asm-generic/bitsperlong.h \
  ../include/uapi/linux/posix_types.h \
  ../include/linux/stddef.h \
  ../include/uapi/linux/stddef.h \
  ../arch/arm64/include/uapi/asm/posix_types.h \
  ../include/uapi/asm-generic/posix_types.h \
  ../include/linux/poison.h \
    $(wildcard include/config/illegal/pointer/value.h) \
    $(wildcard include/config/page/poisoning/zero.h) \
  ../include/linux/const.h \
  ../include/vdso/const.h \
  ../include/uapi/linux/const.h \
  ../include/linux/kernel.h \
    $(wildcard include/config/preempt/voluntary.h) \
    $(wildcard include/config/debug/atomic/sleep.h) \
    $(wildcard include/config/mmu.h) \
    $(wildcard include/config/prove/locking.h) \
    $(wildcard include/config/arch/has/refcount.h) \
    $(wildcard include/config/panic/timeout.h) \
    $(wildcard include/config/tracing.h) \
  /usr/lib/llvm22/lib/clang/22/include/stdarg.h \
  /usr/lib/llvm22/lib/clang/22/include/__stdarg_header_macro.h \
  /usr/lib/llvm22/lib/clang/22/include/__stdarg___gnuc_va_list.h \
  /usr/lib/llvm22/lib/clang/22/include/__stdarg_va_list.h \
  /usr/lib/llvm22/lib/clang/22/include/__stdarg_va_arg.h \
  /usr/lib/llvm22/lib/clang/22/include/__stdarg___va_copy.h \
  /usr/lib/llvm22/lib/clang/22/include/__stdarg_va_copy.h \
  ../include/linux/compiler.h \
    $(wildcard include/config/trace/branch/profiling.h) \
    $(wildcard include/config/profile/all/branches.h) \
    $(wildcard include/config/stack/validation.h) \
    $(wildcard include/config/debug/entry.h) \
    $(wildcard include/config/kasan.h) \
  ../arch/arm64/include/asm/barrier.h \
  ../include/asm-generic/barrier.h \
    $(wildcard include/config/smp.h) \
  ../include/linux/kasan-checks.h \
  ../include/linux/bitops.h \
  ../include/linux/bits.h \
  ../include/vdso/bits.h \
  ../arch/arm64/include/asm/bitops.h \
  ../include/asm-generic/bitops/builtin-__ffs.h \
  ../include/asm-generic/bitops/builtin-ffs.h \
  ../include/asm-generic/bitops/builtin-__fls.h \
  ../include/asm-generic/bitops/builtin-fls.h \
  ../include/asm-generic/bitops/ffz.h \
  ../include/asm-generic/bitops/fls64.h \
  ../include/asm-generic/bitops/find.h \
    $(wildcard include/config/generic/find/first/bit.h) \
  ../include/asm-generic/bitops/sched.h \
  ../include/asm-generic/bitops/hweight.h \
  ../include/asm-generic/bitops/arch_hweight.h \
  ../include/asm-generic/bitops/const_hweight.h \
  ../include/asm-generic/bitops/atomic.h \
  ../include/linux/atomic.h \
    $(wildcard include/config/generic/atomic64.h) \
  ../arch/arm64/include/asm/atomic.h \
    $(wildcard include/config/arm64/lse/atomics.h) \
    $(wildcard include/config/as/lse.h) \
  ../arch/arm64/include/asm/lse.h \
  ../arch/arm64/include/asm/alternative.h \
    $(wildcard include/config/arm64/uao.h) \
  ../arch/arm64/include/asm/cpucaps.h \
  ../arch/arm64/include/asm/insn.h \
  ../include/linux/init.h \
    $(wildcard include/config/strict/kernel/rwx.h) \
    $(wildcard include/config/strict/module/rwx.h) \
  ../arch/arm64/include/asm/atomic_lse.h \
  ../arch/arm64/include/asm/cmpxchg.h \
  ../include/linux/build_bug.h \
  ../include/asm-generic/atomic-long.h \
  ../include/asm-generic/bitops/lock.h \
  ../include/asm-generic/bitops/non-atomic.h \
  ../include/asm-generic/bitops/le.h \
  ../arch/arm64/include/uapi/asm/byteorder.h \
  ../include/linux/byteorder/little_endian.h \
  ../include/uapi/linux/byteorder/little_endian.h \
  ../include/linux/swab.h \
  ../include/uapi/linux/swab.h \
  arch/arm64/include/generated/uapi/asm/swab.h \
  ../include/uapi/asm-generic/swab.h \
  ../include/linux/byteorder/generic.h \
  ../include/asm-generic/bitops/ext2-atomic-setbit.h \
  ../include/linux/log2.h \
    $(wildcard include/config/arch/has/ilog2/u32.h) \
    $(wildcard include/config/arch/has/ilog2/u64.h) \
  ../include/linux/typecheck.h \
  ../include/linux/printk.h \
    $(wildcard include/config/message/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/default.h) \
    $(wildcard include/config/console/loglevel/quiet.h) \
    $(wildcard include/config/early/printk.h) \
    $(wildcard include/config/printk/nmi.h) \
    $(wildcard include/config/printk.h) \
    $(wildcard include/config/dynamic/debug.h) \
  ../include/linux/kern_levels.h \
  ../include/linux/cache.h \
    $(wildcard include/config/arch/has/cache/line/size.h) \
  ../include/uapi/linux/kernel.h \
  ../include/uapi/linux/sysinfo.h \
  ../arch/arm64/include/asm/cache.h \
    $(wildcard include/config/kasan/sw/tags.h) \
  ../arch/arm64/include/asm/cputype.h \
  ../arch/arm64/include/asm/sysreg.h \
    $(wildcard include/config/broken/gas/inst.h) \
    $(wildcard include/config/arm64/pa/bits/52.h) \
    $(wildcard include/config/arm64/4k/pages.h) \
    $(wildcard include/config/arm64/16k/pages.h) \
    $(wildcard include/config/arm64/64k/pages.h) \
  ../arch/arm64/include/asm/compiler.h \
  ../include/linux/limits.h \
  ../include/uapi/linux/limits.h \
  ../include/vdso/limits.h \
  arch/arm64/include/generated/asm/preempt.h \
  ../include/asm-generic/preempt.h \
  ../include/linux/thread_info.h \
    $(wildcard include/config/thread/info/in/task.h) \
    $(wildcard include/config/have/arch/within/stack/frames.h) \
    $(wildcard include/config/hardened/usercopy.h) \
  ../include/linux/bug.h \
    $(wildcard include/config/generic/bug.h) \
    $(wildcard include/config/bug/on/data/corruption.h) \
    $(wildcard include/config/panic/on/data/corruption.h) \
  ../arch/arm64/include/asm/bug.h \
  ../arch/arm64/include/asm/asm-bug.h \
    $(wildcard include/config/debug/bugverbose.h) \
  ../arch/arm64/include/asm/brk-imm.h \
  ../include/asm-generic/bug.h \
    $(wildcard include/config/bug.h) \
    $(wildcard include/config/generic/bug/relative/pointers.h) \
  ../include/linux/restart_block.h \
  ../include/linux/time64.h \
    $(wildcard include/config/64bit/time.h) \
  ../include/linux/math64.h \
    $(wildcard include/config/arch/supports/int128.h) \
  ../include/vdso/math64.h \
  arch/arm64/include/generated/asm/div64.h \
  ../include/asm-generic/div64.h \
  ../include/vdso/time64.h \
  ../include/uapi/linux/time.h \
  ../include/linux/errno.h \
  ../include/uapi/linux/errno.h \
  arch/arm64/include/generated/uapi/asm/errno.h \
  ../include/uapi/asm-generic/errno.h \
  ../include/uapi/asm-generic/errno-base.h \
  ../arch/arm64/include/asm/current.h \
  ../arch/arm64/include/asm/thread_info.h \
    $(wildcard include/config/arm64/sw/ttbr0/pan.h) \
    $(wildcard include/config/shadow/call/stack.h) \
  ../arch/arm64/include/asm/memory.h \
    $(wildcard include/config/arm64/va/bits.h) \
    $(wildcard include/config/vmap/stack.h) \
    $(wildcard include/config/debug/align/rodata.h) \
    $(wildcard include/config/blk/dev/initrd.h) \
    $(wildcard include/config/debug/virtual.h) \
    $(wildcard include/config/sparsemem/vmemmap.h) \
  ../arch/arm64/include/asm/page-def.h \
    $(wildcard include/config/arm64/page/shift.h) \
    $(wildcard include/config/arm64/cont/shift.h) \
  arch/arm64/include/generated/asm/sizes.h \
  ../include/asm-generic/sizes.h \
  ../include/linux/sizes.h \
  ../include/linux/mmdebug.h \
    $(wildcard include/config/debug/vm.h) \
    $(wildcard include/config/debug/vm/pgflags.h) \
  ../include/asm-generic/memory_model.h \
    $(wildcard include/config/flatmem.h) \
    $(wildcard include/config/discontigmem.h) \
    $(wildcard include/config/sparsemem.h) \
  ../include/linux/pfn.h \
  ../arch/arm64/include/asm/stack_pointer.h \
  ../include/linux/spinlock.h \
    $(wildcard include/config/debug/spinlock.h) \
  ../include/linux/irqflags.h \
    $(wildcard include/config/trace/irqflags.h) \
    $(wildcard include/config/irqsoff/tracer.h) \
    $(wildcard include/config/preempt/tracer.h) \
    $(wildcard include/config/trace/irqflags/support.h) \
  ../arch/arm64/include/asm/irqflags.h \
  ../arch/arm64/include/asm/ptrace.h \
    $(wildcard include/config/compat.h) \
  ../arch/arm64/include/uapi/asm/ptrace.h \
  ../arch/arm64/include/asm/hwcap.h \
  ../arch/arm64/include/uapi/asm/hwcap.h \
  ../arch/arm64/include/uapi/asm/sigcontext.h \
  ../include/asm-generic/ptrace.h \
  ../include/linux/bottom_half.h \
  ../include/linux/spinlock_types.h \
  ../arch/arm64/include/asm/spinlock_types.h \
  ../include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/paravirt.h) \
    $(wildcard include/config/nr/cpus.h) \
  ../include/asm-generic/qrwlock_types.h \
  ../include/linux/lockdep.h \
    $(wildcard include/config/lockdep.h) \
    $(wildcard include/config/lock/stat.h) \
  ../include/linux/rwlock_types.h \
  ../arch/arm64/include/asm/spinlock.h \
  arch/arm64/include/generated/asm/qrwlock.h \
  ../include/asm-generic/qrwlock.h \
  ../arch/arm64/include/asm/processor.h \
    $(wildcard include/config/kuser/helpers.h) \
    $(wildcard include/config/have/hw/breakpoint.h) \
    $(wildcard include/config/arm64/tagged/addr/abi.h) \
    $(wildcard include/config/gcc/plugin/stackleak.h) \
  ../include/linux/string.h \
    $(wildcard include/config/binary/printf.h) \
    $(wildcard include/config/fortify/source.h) \
  ../include/uapi/linux/string.h \
  ../arch/arm64/include/asm/string.h \
    $(wildcard include/config/arch/has/uaccess/flushcache.h) \
  ../include/vdso/processor.h \
  ../arch/arm64/include/asm/vdso/processor.h \
  ../arch/arm64/include/asm/cpufeature.h \
    $(wildcard include/config/arm64/sve.h) \
    $(wildcard include/config/arm64/ssbd.h) \
    $(wildcard include/config/arm64/hw/afdbm.h) \
  ../include/linux/jump_label.h \
    $(wildcard include/config/jump/label.h) \
  ../arch/arm64/include/asm/hw_breakpoint.h \
  ../arch/arm64/include/asm/virt.h \
  ../arch/arm64/include/asm/sections.h \
  ../include/asm-generic/sections.h \
  ../arch/arm64/include/asm/pgtable-hwdef.h \
    $(wildcard include/config/pgtable/levels.h) \
    $(wildcard include/config/arm64/pa/bits.h) \
  ../arch/arm64/include/asm/fpsimd.h \
  arch/arm64/include/generated/asm/qspinlock.h \
  ../include/asm-generic/qspinlock.h \
  ../include/linux/rwlock.h \
  ../include/linux/spinlock_api_smp.h \
  ../include/linux/rwlock_api_smp.h \
  ../include/linux/interrupt.h \
    $(wildcard include/config/irq/forced/threading.h) \
    $(wildcard include/config/generic/irq/probe.h) \
    $(wildcard include/config/proc/fs.h) \
    $(wildcard include/config/irq/timings.h) \
  ../include/linux/cpumask.h \
    $(wildcard include/config/cpumask/offstack.h) \
    $(wildcard include/config/hotplug/cpu.h) \
    $(wildcard include/config/debug/per/cpu/maps.h) \
  ../include/linux/threads.h \
    $(wildcard include/config/base/small.h) \
  ../include/linux/bitmap.h \
  ../include/linux/irqreturn.h \
  ../include/linux/irqnr.h \
  ../include/uapi/linux/irqnr.h \
  ../include/linux/hardirq.h \
    $(wildcard include/config/tiny/rcu.h) \
  ../include/linux/ftrace_irq.h \
    $(wildcard include/config/ftrace/nmi/enter.h) \
    $(wildcard include/config/hwlat/tracer.h) \
  ../include/linux/vtime.h \
    $(wildcard include/config/virt/cpu/accounting/native.h) \
    $(wildcard include/config/virt/cpu/accounting/gen.h) \
    $(wildcard include/config/virt/cpu/accounting.h) \
    $(wildcard include/config/irq/time/accounting.h) \
  ../include/linux/context_tracking_state.h \
    $(wildcard include/config/context/tracking.h) \
  ../include/linux/percpu.h \
    $(wildcard include/config/need/per/cpu/embed/first/chunk.h) \
    $(wildcard include/config/need/per/cpu/page/first/chunk.h) \
    $(wildcard include/config/have/setup/per/cpu/area.h) \
  ../include/linux/smp.h \
    $(wildcard include/config/up/late/init.h) \
  ../include/linux/llist.h \
    $(wildcard include/config/arch/have/nmi/safe/cmpxchg.h) \
  ../arch/arm64/include/asm/smp.h \
    $(wildcard include/config/arm64/acpi/parking/protocol.h) \
  ../arch/arm64/include/asm/percpu.h \
  ../include/asm-generic/percpu.h \
  ../include/linux/percpu-defs.h \
    $(wildcard include/config/debug/force/weak/per/cpu.h) \
    $(wildcard include/config/amd/mem/encrypt.h) \
  ../include/linux/static_key.h \
  ../arch/arm64/include/asm/hardirq.h \
  ../arch/arm64/include/asm/irq.h \
  ../include/asm-generic/irq.h \
  ../arch/arm64/include/asm/kvm_arm.h \
  ../arch/arm64/include/asm/esr.h \
  ../include/linux/irq_cpustat.h \
  ../include/linux/hrtimer.h \
    $(wildcard include/config/high/res/timers.h) \
    $(wildcard include/config/time/low/res.h) \
    $(wildcard include/config/timerfd.h) \
    $(wildcard include/config/debug/objects/timers.h) \
  ../include/linux/hrtimer_defs.h \
  ../include/linux/ktime.h \
  ../include/linux/time.h \
    $(wildcard include/config/arch/uses/gettimeoffset.h) \
  ../include/linux/seqlock.h \
  ../include/linux/time32.h \
  ../include/linux/timex.h \
  ../include/uapi/linux/timex.h \
  ../include/uapi/linux/param.h \
  ../arch/arm64/include/uapi/asm/param.h \
  ../include/asm-generic/param.h \
    $(wildcard include/config/hz.h) \
  ../include/uapi/asm-generic/param.h \
  ../arch/arm64/include/asm/timex.h \
  ../arch/arm64/include/asm/arch_timer.h \
    $(wildcard include/config/arm/arch/timer/ool/workaround.h) \
  ../include/clocksource/arm_arch_timer.h \
    $(wildcard include/config/arm/arch/timer.h) \
  ../include/linux/timecounter.h \
  ../include/asm-generic/timex.h \
  ../include/vdso/time32.h \
  ../include/vdso/time.h \
  ../include/linux/jiffies.h \
  ../include/vdso/jiffies.h \
  include/generated/timeconst.h \
  ../include/vdso/ktime.h \
  ../include/linux/timekeeping.h \
  ../include/linux/timekeeping32.h \
  ../include/linux/rbtree.h \
  ../include/linux/rcupdate.h \
    $(wildcard include/config/preempt/rcu.h) \
    $(wildcard include/config/rcu/stall/common.h) \
    $(wildcard include/config/no/hz/full.h) \
    $(wildcard include/config/rcu/nocb/cpu.h) \
    $(wildcard include/config/tasks/rcu.h) \
    $(wildcard include/config/preempt/rt.h) \
    $(wildcard include/config/tree/rcu.h) \
    $(wildcard include/config/debug/objects/rcu/head.h) \
    $(wildcard include/config/prove/rcu.h) \
    $(wildcard include/config/rcu/boost.h) \
    $(wildcard include/config/arch/weak/release/acquire.h) \
  ../include/linux/rcutree.h \
  ../include/linux/timer.h \
    $(wildcard include/config/no/hz/common.h) \
  ../include/linux/debugobjects.h \
    $(wildcard include/config/debug/objects.h) \
    $(wildcard include/config/debug/objects/free.h) \
  ../include/linux/android_kabi.h \
  ../include/linux/timerqueue.h \
  ../include/linux/kref.h \
  ../include/linux/refcount.h \
    $(wildcard include/config/refcount/full.h) \
  ../include/linux/workqueue.h \
    $(wildcard include/config/debug/objects/work.h) \
    $(wildcard include/config/oplus/feature/midas.h) \
    $(wildcard include/config/freezer.h) \
    $(wildcard include/config/sysfs.h) \
    $(wildcard include/config/wq/watchdog.h) \
  ../include/linux/debug_locks.h \
    $(wildcard include/config/debug/locking/api/selftests.h) \

kernel/locking/spinlock.o: $(deps_kernel/locking/spinlock.o)

$(deps_kernel/locking/spinlock.o):
