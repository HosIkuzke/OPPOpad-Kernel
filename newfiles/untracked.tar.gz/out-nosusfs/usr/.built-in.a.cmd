cmd_usr/built-in.a :=  rm -f usr/built-in.a; llvm-ar rcSTPD usr/built-in.a 
