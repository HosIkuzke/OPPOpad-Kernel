cmd_scripts/sortextable := gcc -Wp,-MD,scripts/.sortextable.d -Iscripts -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89  -I../tools/include  -I../tools/include   -o scripts/sortextable ../scripts/sortextable.c   

source_scripts/sortextable := ../scripts/sortextable.c

deps_scripts/sortextable := \
  /usr/include/stdc-predef.h \
  /usr/include/sys/types.h \
  /usr/include/features.h \
  /usr/include/bits/alltypes.h \
  /usr/include/endian.h \
  /usr/include/fortify/sys/select.h \
  /usr/include/sys/select.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/sys/mman.h \
  /usr/include/bits/mman.h \
  /usr/include/sys/stat.h \
  /usr/include/bits/stat.h \
  /usr/include/getopt.h \
  /usr/include/elf.h \
  /usr/include/stdint.h \
  /usr/include/bits/stdint.h \
  /usr/include/fcntl.h \
  /usr/include/bits/fcntl.h \
  /usr/include/setjmp.h \
  /usr/include/bits/setjmp.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \
  ../tools/include/tools/be_byteshift.h \
  ../tools/include/tools/le_byteshift.h \
  ../scripts/sortextable.h \

scripts/sortextable: $(deps_scripts/sortextable)

$(deps_scripts/sortextable):
