cmd_scripts/mod/file2alias.o := gcc -Wp,-MD,scripts/mod/.file2alias.o.d -Iscripts/mod -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89 -c -o scripts/mod/file2alias.o ../scripts/mod/file2alias.c

source_scripts/mod/file2alias.o := ../scripts/mod/file2alias.c

deps_scripts/mod/file2alias.o := \
  /usr/include/stdc-predef.h \
  ../scripts/mod/modpost.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/features.h \
  /usr/include/bits/alltypes.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  /usr/include/stdarg.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/sys/types.h \
  /usr/include/endian.h \
  /usr/include/fortify/sys/select.h \
  /usr/include/sys/select.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/sys/stat.h \
  /usr/include/bits/stat.h \
  /usr/include/sys/mman.h \
  /usr/include/bits/mman.h \
  /usr/include/fcntl.h \
  /usr/include/bits/fcntl.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \
  /usr/include/elf.h \
  /usr/include/stdint.h \
  /usr/include/bits/stdint.h \
  scripts/mod/elfconfig.h \
  scripts/mod/devicetable-offsets.h \
  /usr/include/ctype.h \
  /usr/include/stdbool.h \
  ../scripts/mod/../../include/linux/mod_devicetable.h \

scripts/mod/file2alias.o: $(deps_scripts/mod/file2alias.o)

$(deps_scripts/mod/file2alias.o):
