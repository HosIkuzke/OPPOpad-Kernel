cmd_scripts/mod/modpost.o := gcc -Wp,-MD,scripts/mod/.modpost.o.d -Iscripts/mod -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89 -c -o scripts/mod/modpost.o ../scripts/mod/modpost.c

source_scripts/mod/modpost.o := ../scripts/mod/modpost.c

deps_scripts/mod/modpost.o := \
    $(wildcard include/config/modversions.h) \
    $(wildcard include/config/module/srcversion/all.h) \
    $(wildcard include/config/cfi/clang.h) \
    $(wildcard include/config/relocatable.h) \
    $(wildcard include/config/module/unload.h) \
    $(wildcard include/config/retpoline.h) \
    $(wildcard include/config/debug/section/mismatch.h) \
    $(wildcard include/config/section/mismatch/warn/only.h) \
  /usr/include/stdc-predef.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/features.h \
  /usr/include/bits/alltypes.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/ctype.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  /usr/include/stdbool.h \
  /usr/include/errno.h \
  /usr/include/bits/errno.h \
  ../scripts/mod/modpost.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/stdarg.h \
  /usr/include/sys/types.h \
  /usr/include/endian.h \
  /usr/include/fortify/sys/select.h \
  /usr/include/sys/select.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/sys/stat.h \
  /usr/include/bits/stat.h \
  /usr/include/sys/mman.h \
  /usr/include/bits/mman.h \
  /usr/include/fcntl.h \
  /usr/include/bits/fcntl.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \
  /usr/include/elf.h \
  /usr/include/stdint.h \
  /usr/include/bits/stdint.h \
  scripts/mod/elfconfig.h \
  ../scripts/mod/../../include/linux/license.h \

scripts/mod/modpost.o: $(deps_scripts/mod/modpost.o)

$(deps_scripts/mod/modpost.o):
