cmd_scripts/mod/sumversion.o := gcc -Wp,-MD,scripts/mod/.sumversion.o.d -Iscripts/mod -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89 -c -o scripts/mod/sumversion.o ../scripts/mod/sumversion.c

source_scripts/mod/sumversion.o := ../scripts/mod/sumversion.c

deps_scripts/mod/sumversion.o := \
  /usr/include/stdc-predef.h \
  /usr/include/netinet/in.h \
  /usr/include/features.h \
  /usr/include/inttypes.h \
  /usr/include/stdint.h \
  /usr/include/bits/alltypes.h \
  /usr/include/bits/stdint.h \
  /usr/include/fortify/sys/socket.h \
  /usr/include/sys/socket.h \
  /usr/include/bits/socket.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/ctype.h \
  /usr/include/errno.h \
  /usr/include/bits/errno.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  ../scripts/mod/modpost.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/stdarg.h \
  /usr/include/sys/types.h \
  /usr/include/endian.h \
  /usr/include/fortify/sys/select.h \
  /usr/include/sys/select.h \
  /usr/include/sys/stat.h \
  /usr/include/bits/stat.h \
  /usr/include/sys/mman.h \
  /usr/include/bits/mman.h \
  /usr/include/fcntl.h \
  /usr/include/bits/fcntl.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \
  /usr/include/elf.h \
  scripts/mod/elfconfig.h \

scripts/mod/sumversion.o: $(deps_scripts/mod/sumversion.o)

$(deps_scripts/mod/sumversion.o):
