cmd_scripts/dtc/treesource.o := gcc -Wp,-MD,scripts/dtc/.treesource.o.d -Iscripts/dtc -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89 -I ../scripts/dtc/libfdt -DNO_YAML -c -o scripts/dtc/treesource.o ../scripts/dtc/treesource.c

source_scripts/dtc/treesource.o := ../scripts/dtc/treesource.c

deps_scripts/dtc/treesource.o := \
  /usr/include/stdc-predef.h \
  ../scripts/dtc/dtc.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/features.h \
  /usr/include/bits/alltypes.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  /usr/include/stdint.h \
  /usr/include/bits/stdint.h \
  /usr/include/stdbool.h \
  /usr/include/stdarg.h \
  /usr/include/assert.h \
  /usr/include/ctype.h \
  /usr/include/errno.h \
  /usr/include/bits/errno.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \
  /usr/include/inttypes.h \
  ../scripts/dtc/libfdt/libfdt_env.h \
  /usr/include/stddef.h \
  /usr/include/limits.h \
  ../scripts/dtc/libfdt/fdt.h \
  ../scripts/dtc/util.h \
  /usr/include/getopt.h \
  ../scripts/dtc/srcpos.h \

scripts/dtc/treesource.o: $(deps_scripts/dtc/treesource.o)

$(deps_scripts/dtc/treesource.o):
