cmd_scripts/kconfig/zconf.tab.o := gcc -Wp,-MD,scripts/kconfig/.zconf.tab.o.d -Iscripts/kconfig -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89  -I../scripts/kconfig -c -o scripts/kconfig/zconf.tab.o scripts/kconfig/zconf.tab.c

source_scripts/kconfig/zconf.tab.o := scripts/kconfig/zconf.tab.c

deps_scripts/kconfig/zconf.tab.o := \
  /usr/include/stdc-predef.h \
  /usr/include/ctype.h \
  /usr/include/features.h \
  /usr/include/bits/alltypes.h \
  /usr/include/stdarg.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/stdbool.h \
  ../scripts/kconfig/lkc.h \
    $(wildcard include/config/prefix.h) \
  ../scripts/kconfig/expr.h \
  /usr/include/assert.h \
  ../scripts/kconfig/list.h \
  ../scripts/kconfig/lkc_proto.h \
  ../scripts/kconfig/kconf_id.c \
  scripts/kconfig/zconf.lex.c \
  /usr/include/errno.h \
  /usr/include/bits/errno.h \
  /usr/include/limits.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \
  ../scripts/kconfig/util.c \
  ../scripts/kconfig/lkc.h \
  ../scripts/kconfig/confdata.c \
  /usr/include/sys/stat.h \
  /usr/include/bits/stat.h \
  /usr/include/fcntl.h \
  /usr/include/bits/fcntl.h \
  /usr/include/time.h \
  ../scripts/kconfig/expr.c \
  ../scripts/kconfig/symbol.c \
  /usr/include/regex.h \
  /usr/include/sys/utsname.h \
  ../scripts/kconfig/menu.c \
  ../scripts/kconfig/preprocess.c \

scripts/kconfig/zconf.tab.o: $(deps_scripts/kconfig/zconf.tab.o)

$(deps_scripts/kconfig/zconf.tab.o):
