cmd_scripts/kconfig/conf.o := gcc -Wp,-MD,scripts/kconfig/.conf.o.d -Iscripts/kconfig -Wall -Wmissing-prototypes -Wstrict-prototypes -O2 -fomit-frame-pointer -std=gnu89 -c -o scripts/kconfig/conf.o ../scripts/kconfig/conf.c

source_scripts/kconfig/conf.o := ../scripts/kconfig/conf.c

deps_scripts/kconfig/conf.o := \
  /usr/include/stdc-predef.h \
  /usr/include/ctype.h \
  /usr/include/features.h \
  /usr/include/bits/alltypes.h \
  /usr/include/limits.h \
  /usr/include/bits/limits.h \
  /usr/include/fortify/stdio.h \
  /usr/include/stdio.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/fortify/stdlib.h \
  /usr/include/stdlib.h \
  /usr/include/alloca.h \
  /usr/include/limits.h \
  /usr/include/fortify/string.h \
  /usr/include/string.h \
  /usr/include/fortify/strings.h \
  /usr/include/strings.h \
  /usr/include/time.h \
  /usr/include/fortify/unistd.h \
  /usr/include/unistd.h \
  /usr/include/getopt.h \
  /usr/include/sys/stat.h \
  /usr/include/bits/stat.h \
  /usr/include/sys/time.h \
  /usr/include/fortify/sys/select.h \
  /usr/include/sys/select.h \
  /usr/include/fortify/fortify-headers.h \
  /usr/include/errno.h \
  /usr/include/bits/errno.h \
  ../scripts/kconfig/lkc.h \
    $(wildcard include/config/prefix.h) \
  ../scripts/kconfig/expr.h \
  /usr/include/assert.h \
  ../scripts/kconfig/list.h \
  /usr/include/stdbool.h \
  ../scripts/kconfig/lkc_proto.h \
  /usr/include/stdarg.h \

scripts/kconfig/conf.o: $(deps_scripts/kconfig/conf.o)

$(deps_scripts/kconfig/conf.o):
