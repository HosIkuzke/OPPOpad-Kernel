/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#1 SMP Sat Nov 14 09:57:00 UTC 2026"
#define LINUX_COMPILE_BY "eta"
#define LINUX_COMPILE_HOST "eta"
#define LINUX_COMPILER "Alpine clang version 22.1.3, LLD 22.1.3"
