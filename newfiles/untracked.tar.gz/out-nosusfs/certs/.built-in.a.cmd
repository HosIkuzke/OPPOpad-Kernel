cmd_certs/built-in.a :=  rm -f certs/built-in.a; llvm-ar rcSTPD certs/built-in.a 
