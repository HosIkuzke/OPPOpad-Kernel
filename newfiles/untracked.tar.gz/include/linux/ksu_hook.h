/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _LINUX_KSU_HOOK_H
#define _LINUX_KSU_HOOK_H

#ifdef CONFIG_KSU
#include <linux/types.h>

struct file;
struct filename;
struct path;
extern bool ksu_execveat_hook;
extern bool ksu_vfs_read_hook;
extern bool ksu_su_compat_enabled;
int ksu_handle_execveat(int *fd, struct filename **filename,
		      void *argv, void *envp, int *flags);
int ksu_install_su_fd(void);
int ksu_handle_vfs_read(struct file **file, char __user **buf,
			size_t *count, loff_t **pos);
void ksu_handle_vfs_fstat(int fd, loff_t *size);
#ifdef CONFIG_KSU_SUSFS
/* Consumes name through filename_lookup, including errors. */
int ksu_filename_lookup(int dfd, struct filename *name, unsigned int flags,
			struct path *path);
int ksu_handle_faccessat(int *dfd, struct filename **filename,
			 int *mode, int *flags);
int ksu_handle_stat(int *dfd, struct filename **filename, int *flags);
int ksu_handle_setresuid(uid_t ruid, uid_t euid, uid_t suid);
int ksu_supercall_reboot_handler(void __user **arg);
#else
int ksu_handle_faccessat(int *dfd, const char __user **filename,
			 int *mode, int *flags);
int ksu_handle_stat(int *dfd, const char __user **filename, int *flags);
int ksu_handle_sys_reboot(int magic1, int magic2, unsigned int cmd,
			void __user **arg);
#endif
#endif /* CONFIG_KSU */
#endif /* _LINUX_KSU_HOOK_H */
